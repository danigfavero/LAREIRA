/*Este modulo contem a estoria e toda a inicializacao dos elementos.*/
